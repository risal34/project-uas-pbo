package com.partials;
import java.awt.Color;

public class cColor {

  public static final Color BLUE = new Color(41, 85, 164);
  public static final Color RED = new Color(255, 64, 129);
  public static final Color BLACK = new Color(0, 0, 0);
  public static final Color WHITE = new Color(255, 255, 255);
  public static final Color WHITE90 = new Color(255, 255, 255, 230);
  public static final Color WHITE_GRAY = new Color(241, 241, 241);
  public static final Color BLACK_GRAY = new Color(48, 48, 48);
  public static final Color GRAY = new Color(118, 118, 118);
  public static final Color GREEN = new Color(45, 204, 147);
  
}
