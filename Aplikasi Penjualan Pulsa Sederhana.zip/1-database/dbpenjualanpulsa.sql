/*
SQLyog Ultimate v12.4.3 (64 bit)
MySQL - 10.4.13-MariaDB : Database - dbpenjualanpulsa
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbpenjualanpulsa` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `dbpenjualanpulsa`;

/*Table structure for table `tblcustomer` */

DROP TABLE IF EXISTS `tblcustomer`;

CREATE TABLE `tblcustomer` (
  `idCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `namaCustomer` varchar(255) NOT NULL,
  `nomorHpCustomer` char(12) NOT NULL,
  `passwordCustomer` varchar(255) NOT NULL,
  `emailCustomer` varchar(255) DEFAULT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idCustomer`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tblcustomer` */

LOCK TABLES `tblcustomer` WRITE;

insert  into `tblcustomer`(`idCustomer`,`namaCustomer`,`nomorHpCustomer`,`passwordCustomer`,`emailCustomer`,`statusAktif`) values 
(1,'Risal Maulana','081234567890','risal','risal@gmail.com','1'),
(2,'Rijal Lullabib','080987654321','rijal','rijal@gmail.com','1'),
(3,'Reynaldi','081234567891','rey','reynaldi@gmail.com','1'),
(4,'Dudu','081234576890','dudu','','1');

UNLOCK TABLES;

/*Table structure for table `tblmitra` */

DROP TABLE IF EXISTS `tblmitra`;

CREATE TABLE `tblmitra` (
  `idMitra` int(11) NOT NULL AUTO_INCREMENT,
  `namaMitra` varchar(255) NOT NULL,
  `emailMitra` varchar(255) NOT NULL,
  `passwordMitra` varchar(255) NOT NULL,
  `statusVerifikasi` enum('0','1') NOT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idMitra`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tblmitra` */

LOCK TABLES `tblmitra` WRITE;

insert  into `tblmitra`(`idMitra`,`namaMitra`,`emailMitra`,`passwordMitra`,`statusVerifikasi`,`statusAktif`) values 
(1,'AhTong Cell','ahtong@gmail.com','ahtong','1','1'),
(2,'Tok Dalang Cell','tokdalang@gmail.com','tokdalang','1','1'),
(3,'-','-','-','0','0'),
(4,'Jon Cell','jon@gmail.com','jon','1','1');

UNLOCK TABLES;

/*Table structure for table `tblpaket` */

DROP TABLE IF EXISTS `tblpaket`;

CREATE TABLE `tblpaket` (
  `idPaket` int(11) NOT NULL AUTO_INCREMENT,
  `namaPaket` varchar(255) NOT NULL,
  `deskripsiPaket` text NOT NULL,
  `kuota` int(11) NOT NULL,
  `hargaPaket` int(11) NOT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idPaket`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tblpaket` */

LOCK TABLES `tblpaket` WRITE;

insert  into `tblpaket`(`idPaket`,`namaPaket`,`deskripsiPaket`,`kuota`,`hargaPaket`,`statusAktif`) values 
(1,'Paket Hemat','Paket Hemat\r\nMasa Aktif 5 Hari\r\nIternet 3 GB\r\n',3,8000,'1'),
(2,'Combo Spesial','Paket Combo Spesial\r\nMasa Aktif 5 Hari\r\nKuota Nonton 1\r\nIternet 3 GB',4,13000,'1'),
(3,'Internet Sakti','Internet Sakti\r\nMasa Aktif 30 Hari\r\nInternet 30 GB',30,50000,'1'),
(4,'Paket Streaming','Paket Streaming\r\nMasa Aktif 30 Hari\r\nInternet 10 GB\r\nStreaming 40 GB',50,120000,'1');

UNLOCK TABLES;

/*Table structure for table `tblpulsakuotacustomer` */

DROP TABLE IF EXISTS `tblpulsakuotacustomer`;

CREATE TABLE `tblpulsakuotacustomer` (
  `idPulsaKuotaCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `idCustomer` int(11) NOT NULL,
  `pulsaCustomer` int(11) NOT NULL,
  `kuotaCustomer` int(11) NOT NULL,
  PRIMARY KEY (`idPulsaKuotaCustomer`),
  KEY `idCustomerPulsaKuota` (`idCustomer`),
  CONSTRAINT `idCustomerPulsaKuota` FOREIGN KEY (`idCustomer`) REFERENCES `tblcustomer` (`idCustomer`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tblpulsakuotacustomer` */

LOCK TABLES `tblpulsakuotacustomer` WRITE;

insert  into `tblpulsakuotacustomer`(`idPulsaKuotaCustomer`,`idCustomer`,`pulsaCustomer`,`kuotaCustomer`) values 
(1,1,100000,0),
(2,2,0,30),
(3,3,10000,0),
(4,4,50000,30);

UNLOCK TABLES;

/*Table structure for table `tblsaldomitra` */

DROP TABLE IF EXISTS `tblsaldomitra`;

CREATE TABLE `tblsaldomitra` (
  `idSaldoMitra` int(11) NOT NULL AUTO_INCREMENT,
  `idMitra` int(11) NOT NULL,
  `saldoMitra` int(11) NOT NULL,
  PRIMARY KEY (`idSaldoMitra`),
  KEY `idMitraSaldoMitra` (`idMitra`),
  CONSTRAINT `idMitraSaldoMitra` FOREIGN KEY (`idMitra`) REFERENCES `tblmitra` (`idMitra`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tblsaldomitra` */

LOCK TABLES `tblsaldomitra` WRITE;

insert  into `tblsaldomitra`(`idSaldoMitra`,`idMitra`,`saldoMitra`) values 
(1,1,140000),
(2,2,100000),
(3,3,0),
(4,4,50000);

UNLOCK TABLES;

/*Table structure for table `tbltransaksipaket` */

DROP TABLE IF EXISTS `tbltransaksipaket`;

CREATE TABLE `tbltransaksipaket` (
  `idTransaksiPaket` int(11) NOT NULL AUTO_INCREMENT,
  `idCustomer` int(11) NOT NULL,
  `idPaket` int(11) NOT NULL,
  `waktuTransaksi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `statusTransaksi` enum('diproses','selesai') NOT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idTransaksiPaket`),
  KEY `idCustomerTransaksiPaket` (`idCustomer`),
  KEY `idPaketTransaksiPaket` (`idPaket`),
  CONSTRAINT `idCustomerTransaksiPaket` FOREIGN KEY (`idCustomer`) REFERENCES `tblcustomer` (`idCustomer`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `idPaketTransaksiPaket` FOREIGN KEY (`idPaket`) REFERENCES `tblpaket` (`idPaket`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbltransaksipaket` */

LOCK TABLES `tbltransaksipaket` WRITE;

insert  into `tbltransaksipaket`(`idTransaksiPaket`,`idCustomer`,`idPaket`,`waktuTransaksi`,`statusTransaksi`,`statusAktif`) values 
(1,2,3,'2024-07-01 11:20:46','selesai','1'),
(2,4,3,'2024-07-16 09:50:08','selesai','1');

UNLOCK TABLES;

/*Table structure for table `tbltransaksipulsa` */

DROP TABLE IF EXISTS `tbltransaksipulsa`;

CREATE TABLE `tbltransaksipulsa` (
  `idTransaksiPulsa` int(11) NOT NULL AUTO_INCREMENT,
  `idCustomer` int(11) NOT NULL,
  `jumlahPulsa` int(11) NOT NULL,
  `idMitra` int(11) NOT NULL,
  `waktuTransaksi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `statusTransaksi` enum('diproses','selesai') NOT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idTransaksiPulsa`),
  KEY `idCustomerTransaksiPulsa` (`idCustomer`),
  KEY `idMitraTransaksiPulsa` (`idMitra`),
  CONSTRAINT `idCustomerTransaksiPulsa` FOREIGN KEY (`idCustomer`) REFERENCES `tblcustomer` (`idCustomer`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `idMitraTransaksiPulsa` FOREIGN KEY (`idMitra`) REFERENCES `tblmitra` (`idMitra`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbltransaksipulsa` */

LOCK TABLES `tbltransaksipulsa` WRITE;

insert  into `tbltransaksipulsa`(`idTransaksiPulsa`,`idCustomer`,`jumlahPulsa`,`idMitra`,`waktuTransaksi`,`statusTransaksi`,`statusAktif`) values 
(2,3,10000,1,'2024-07-01 11:10:25','selesai','1'),
(3,2,50000,2,'2024-07-01 11:20:11','selesai','1'),
(4,4,100000,4,'2024-07-16 09:47:56','selesai','1');

UNLOCK TABLES;

/*Table structure for table `tbltransaksisaldo` */

DROP TABLE IF EXISTS `tbltransaksisaldo`;

CREATE TABLE `tbltransaksisaldo` (
  `idTransaksiSaldo` int(11) NOT NULL AUTO_INCREMENT,
  `idMitra` int(11) NOT NULL,
  `jumlahSaldo` int(11) NOT NULL,
  `waktuTransaksi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `statusTransaksi` enum('diproses','selesai') NOT NULL,
  `statusAktif` enum('1','0') NOT NULL,
  PRIMARY KEY (`idTransaksiSaldo`),
  KEY `idMitraTransaksiSaldo` (`idMitra`),
  CONSTRAINT `idMitraTransaksiSaldo` FOREIGN KEY (`idMitra`) REFERENCES `tblmitra` (`idMitra`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbltransaksisaldo` */

LOCK TABLES `tbltransaksisaldo` WRITE;

UNLOCK TABLES;

/* Trigger structure for table `tblcustomer` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insertPulsaKuotaCustomer` */$$

/*!50003 CREATE */ /*!50003 TRIGGER `insertPulsaKuotaCustomer` AFTER INSERT ON `tblcustomer` FOR EACH ROW BEGIN
    
    INSERT INTO tblpulsakuotacustomer VALUES ( NULL, NEW.idCustomer, 0, 0 );

    END */$$


DELIMITER ;

/* Trigger structure for table `tblmitra` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insertSaldoMitra` */$$

/*!50003 CREATE */ /*!50003 TRIGGER `insertSaldoMitra` AFTER INSERT ON `tblmitra` FOR EACH ROW BEGIN
    
    INSERT INTO tblsaldomitra VALUES ( NULL, NEW.idMitra, 0 );

    END */$$


DELIMITER ;

/* Trigger structure for table `tbltransaksipulsa` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `updatePulsaCustomer` */$$

/*!50003 CREATE */ /*!50003 TRIGGER `updatePulsaCustomer` AFTER UPDATE ON `tbltransaksipulsa` FOR EACH ROW BEGIN
    
    UPDATE tblpulsakuotacustomer SET pulsaCustomer = pulsaCustomer + OLD.jumlahPulsa WHERE idCustomer = OLD.idCustomer;
    UPDATE tblsaldomitra SET saldoMitra = saldoMitra - OLD.jumlahPulsa WHERE idMitra = NEW.idMitra;

    END */$$


DELIMITER ;

/* Trigger structure for table `tbltransaksisaldo` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `updateSaldoMitra` */$$

/*!50003 CREATE */ /*!50003 TRIGGER `updateSaldoMitra` AFTER UPDATE ON `tbltransaksisaldo` FOR EACH ROW BEGIN
    
    UPDATE tblsaldomitra SET saldoMitra = saldoMitra + OLD.jumlahSaldo WHERE idMitra = OLD.idMitra;

    END */$$


DELIMITER ;

/*Table structure for table `vwallmitra` */

DROP TABLE IF EXISTS `vwallmitra`;

/*!50001 DROP VIEW IF EXISTS `vwallmitra` */;
/*!50001 DROP TABLE IF EXISTS `vwallmitra` */;

/*!50001 CREATE TABLE  `vwallmitra`(
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `emailMitra` varchar(255) ,
 `passwordMitra` varchar(255) ,
 `statusVerifikasi` enum('0','1') 
)*/;

/*Table structure for table `vwallpaket` */

DROP TABLE IF EXISTS `vwallpaket`;

/*!50001 DROP VIEW IF EXISTS `vwallpaket` */;
/*!50001 DROP TABLE IF EXISTS `vwallpaket` */;

/*!50001 CREATE TABLE  `vwallpaket`(
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `deskripsiPaket` text ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `statusAktif` enum('1','0') 
)*/;

/*Table structure for table `vwalltransaksipaket` */

DROP TABLE IF EXISTS `vwalltransaksipaket`;

/*!50001 DROP VIEW IF EXISTS `vwalltransaksipaket` */;
/*!50001 DROP TABLE IF EXISTS `vwalltransaksipaket` */;

/*!50001 CREATE TABLE  `vwalltransaksipaket`(
 `idTransaksiPaket` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwalltransaksipulsa` */

DROP TABLE IF EXISTS `vwalltransaksipulsa`;

/*!50001 DROP VIEW IF EXISTS `vwalltransaksipulsa` */;
/*!50001 DROP TABLE IF EXISTS `vwalltransaksipulsa` */;

/*!50001 CREATE TABLE  `vwalltransaksipulsa`(
 `idTransaksiPulsa` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `jumlahPulsa` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwalltransaksisaldo` */

DROP TABLE IF EXISTS `vwalltransaksisaldo`;

/*!50001 DROP VIEW IF EXISTS `vwalltransaksisaldo` */;
/*!50001 DROP TABLE IF EXISTS `vwalltransaksisaldo` */;

/*!50001 CREATE TABLE  `vwalltransaksisaldo`(
 `idTransaksiSaldo` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `jumlahSaldo` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwcustomer` */

DROP TABLE IF EXISTS `vwcustomer`;

/*!50001 DROP VIEW IF EXISTS `vwcustomer` */;
/*!50001 DROP TABLE IF EXISTS `vwcustomer` */;

/*!50001 CREATE TABLE  `vwcustomer`(
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `passwordCustomer` varchar(255) ,
 `emailCustomer` varchar(255) 
)*/;

/*Table structure for table `vwdonetransaksipaket` */

DROP TABLE IF EXISTS `vwdonetransaksipaket`;

/*!50001 DROP VIEW IF EXISTS `vwdonetransaksipaket` */;
/*!50001 DROP TABLE IF EXISTS `vwdonetransaksipaket` */;

/*!50001 CREATE TABLE  `vwdonetransaksipaket`(
 `idTransaksiPaket` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwdonetransaksipulsa` */

DROP TABLE IF EXISTS `vwdonetransaksipulsa`;

/*!50001 DROP VIEW IF EXISTS `vwdonetransaksipulsa` */;
/*!50001 DROP TABLE IF EXISTS `vwdonetransaksipulsa` */;

/*!50001 CREATE TABLE  `vwdonetransaksipulsa`(
 `idTransaksiPulsa` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `jumlahPulsa` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwdonetransaksisaldo` */

DROP TABLE IF EXISTS `vwdonetransaksisaldo`;

/*!50001 DROP VIEW IF EXISTS `vwdonetransaksisaldo` */;
/*!50001 DROP TABLE IF EXISTS `vwdonetransaksisaldo` */;

/*!50001 CREATE TABLE  `vwdonetransaksisaldo`(
 `idTransaksiSaldo` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `jumlahSaldo` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwmitranonverifikasi` */

DROP TABLE IF EXISTS `vwmitranonverifikasi`;

/*!50001 DROP VIEW IF EXISTS `vwmitranonverifikasi` */;
/*!50001 DROP TABLE IF EXISTS `vwmitranonverifikasi` */;

/*!50001 CREATE TABLE  `vwmitranonverifikasi`(
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `emailMitra` varchar(255) ,
 `passwordMitra` varchar(255) ,
 `statusVerifikasi` enum('0','1') 
)*/;

/*Table structure for table `vwmitraterverifikasi` */

DROP TABLE IF EXISTS `vwmitraterverifikasi`;

/*!50001 DROP VIEW IF EXISTS `vwmitraterverifikasi` */;
/*!50001 DROP TABLE IF EXISTS `vwmitraterverifikasi` */;

/*!50001 CREATE TABLE  `vwmitraterverifikasi`(
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `emailMitra` varchar(255) ,
 `passwordMitra` varchar(255) ,
 `statusVerifikasi` enum('0','1') 
)*/;

/*Table structure for table `vwpaketaktif` */

DROP TABLE IF EXISTS `vwpaketaktif`;

/*!50001 DROP VIEW IF EXISTS `vwpaketaktif` */;
/*!50001 DROP TABLE IF EXISTS `vwpaketaktif` */;

/*!50001 CREATE TABLE  `vwpaketaktif`(
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `deskripsiPaket` text ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `statusAktif` enum('1','0') 
)*/;

/*Table structure for table `vwpaketnonaktif` */

DROP TABLE IF EXISTS `vwpaketnonaktif`;

/*!50001 DROP VIEW IF EXISTS `vwpaketnonaktif` */;
/*!50001 DROP TABLE IF EXISTS `vwpaketnonaktif` */;

/*!50001 CREATE TABLE  `vwpaketnonaktif`(
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `deskripsiPaket` text ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `statusAktif` enum('1','0') 
)*/;

/*Table structure for table `vwpendingtransaksipaket` */

DROP TABLE IF EXISTS `vwpendingtransaksipaket`;

/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksipaket` */;
/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksipaket` */;

/*!50001 CREATE TABLE  `vwpendingtransaksipaket`(
 `idTransaksiPaket` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `idPaket` int(11) ,
 `namaPaket` varchar(255) ,
 `kuota` int(11) ,
 `hargaPaket` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwpendingtransaksipulsa` */

DROP TABLE IF EXISTS `vwpendingtransaksipulsa`;

/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksipulsa` */;
/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksipulsa` */;

/*!50001 CREATE TABLE  `vwpendingtransaksipulsa`(
 `idTransaksiPulsa` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `jumlahPulsa` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwpendingtransaksisaldo` */

DROP TABLE IF EXISTS `vwpendingtransaksisaldo`;

/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksisaldo` */;
/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksisaldo` */;

/*!50001 CREATE TABLE  `vwpendingtransaksisaldo`(
 `idTransaksiSaldo` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `jumlahSaldo` int(11) ,
 `waktuTransaksi` timestamp ,
 `statusTransaksi` enum('diproses','selesai') 
)*/;

/*Table structure for table `vwpulsakuotacustomer` */

DROP TABLE IF EXISTS `vwpulsakuotacustomer`;

/*!50001 DROP VIEW IF EXISTS `vwpulsakuotacustomer` */;
/*!50001 DROP TABLE IF EXISTS `vwpulsakuotacustomer` */;

/*!50001 CREATE TABLE  `vwpulsakuotacustomer`(
 `idPulsaKuotaCustomer` int(11) ,
 `idCustomer` int(11) ,
 `namaCustomer` varchar(255) ,
 `nomorHpCustomer` char(12) ,
 `pulsaCustomer` int(11) ,
 `kuotaCustomer` int(11) 
)*/;

/*Table structure for table `vwsaldomitra` */

DROP TABLE IF EXISTS `vwsaldomitra`;

/*!50001 DROP VIEW IF EXISTS `vwsaldomitra` */;
/*!50001 DROP TABLE IF EXISTS `vwsaldomitra` */;

/*!50001 CREATE TABLE  `vwsaldomitra`(
 `idSaldoMitra` int(11) ,
 `idMitra` int(11) ,
 `namaMitra` varchar(255) ,
 `emailMitra` varchar(255) ,
 `saldoMitra` int(11) 
)*/;

/*View structure for view vwallmitra */

/*!50001 DROP TABLE IF EXISTS `vwallmitra` */;
/*!50001 DROP VIEW IF EXISTS `vwallmitra` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwallmitra` AS (select `tblmitra`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tblmitra`.`emailMitra` AS `emailMitra`,`tblmitra`.`passwordMitra` AS `passwordMitra`,`tblmitra`.`statusVerifikasi` AS `statusVerifikasi` from `tblmitra` where `tblmitra`.`statusAktif` = '1') */;

/*View structure for view vwallpaket */

/*!50001 DROP TABLE IF EXISTS `vwallpaket` */;
/*!50001 DROP VIEW IF EXISTS `vwallpaket` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwallpaket` AS (select `tblpaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`deskripsiPaket` AS `deskripsiPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tblpaket`.`statusAktif` AS `statusAktif` from `tblpaket`) */;

/*View structure for view vwalltransaksipaket */

/*!50001 DROP TABLE IF EXISTS `vwalltransaksipaket` */;
/*!50001 DROP VIEW IF EXISTS `vwalltransaksipaket` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwalltransaksipaket` AS (select `tbltransaksipaket`.`idTransaksiPaket` AS `idTransaksiPaket`,`tbltransaksipaket`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tbltransaksipaket`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipaket`.`statusTransaksi` AS `statusTransaksi` from ((`tbltransaksipaket` join `tblcustomer` on(`tbltransaksipaket`.`idCustomer` = `tblcustomer`.`idCustomer`)) join `tblpaket` on(`tbltransaksipaket`.`idPaket` = `tblpaket`.`idPaket`)) where `tbltransaksipaket`.`statusAktif` = '1') */;

/*View structure for view vwalltransaksipulsa */

/*!50001 DROP TABLE IF EXISTS `vwalltransaksipulsa` */;
/*!50001 DROP VIEW IF EXISTS `vwalltransaksipulsa` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwalltransaksipulsa` AS (select `tbltransaksipulsa`.`idTransaksiPulsa` AS `idTransaksiPulsa`,`tbltransaksipulsa`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipulsa`.`jumlahPulsa` AS `jumlahPulsa`,`tbltransaksipulsa`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tbltransaksipulsa`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipulsa`.`statusTransaksi` AS `statusTransaksi` from ((`tbltransaksipulsa` join `tblcustomer` on(`tbltransaksipulsa`.`idCustomer` = `tblcustomer`.`idCustomer`)) join `tblmitra` on(`tbltransaksipulsa`.`idMitra` = `tblmitra`.`idMitra`)) where `tbltransaksipulsa`.`statusAktif` = '1') */;

/*View structure for view vwalltransaksisaldo */

/*!50001 DROP TABLE IF EXISTS `vwalltransaksisaldo` */;
/*!50001 DROP VIEW IF EXISTS `vwalltransaksisaldo` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwalltransaksisaldo` AS (select `tbltransaksisaldo`.`idTransaksiSaldo` AS `idTransaksiSaldo`,`tbltransaksisaldo`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tbltransaksisaldo`.`jumlahSaldo` AS `jumlahSaldo`,`tbltransaksisaldo`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksisaldo`.`statusTransaksi` AS `statusTransaksi` from (`tbltransaksisaldo` join `tblmitra` on(`tbltransaksisaldo`.`idMitra` = `tblmitra`.`idMitra`)) where `tbltransaksisaldo`.`statusAktif` = '1') */;

/*View structure for view vwcustomer */

/*!50001 DROP TABLE IF EXISTS `vwcustomer` */;
/*!50001 DROP VIEW IF EXISTS `vwcustomer` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwcustomer` AS (select `tblcustomer`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tblcustomer`.`passwordCustomer` AS `passwordCustomer`,`tblcustomer`.`emailCustomer` AS `emailCustomer` from `tblcustomer` where `tblcustomer`.`statusAktif` = '1') */;

/*View structure for view vwdonetransaksipaket */

/*!50001 DROP TABLE IF EXISTS `vwdonetransaksipaket` */;
/*!50001 DROP VIEW IF EXISTS `vwdonetransaksipaket` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwdonetransaksipaket` AS (select `tbltransaksipaket`.`idTransaksiPaket` AS `idTransaksiPaket`,`tbltransaksipaket`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tbltransaksipaket`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipaket`.`statusTransaksi` AS `statusTransaksi` from ((`tbltransaksipaket` join `tblcustomer` on(`tbltransaksipaket`.`idCustomer` = `tblcustomer`.`idCustomer`)) join `tblpaket` on(`tbltransaksipaket`.`idPaket` = `tblpaket`.`idPaket`)) where `tbltransaksipaket`.`statusAktif` = '1' and `tbltransaksipaket`.`statusTransaksi` = 'selesai') */;

/*View structure for view vwdonetransaksipulsa */

/*!50001 DROP TABLE IF EXISTS `vwdonetransaksipulsa` */;
/*!50001 DROP VIEW IF EXISTS `vwdonetransaksipulsa` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwdonetransaksipulsa` AS (select `tbltransaksipulsa`.`idTransaksiPulsa` AS `idTransaksiPulsa`,`tbltransaksipulsa`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipulsa`.`jumlahPulsa` AS `jumlahPulsa`,`tbltransaksipulsa`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tbltransaksipulsa`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipulsa`.`statusTransaksi` AS `statusTransaksi` from ((`tbltransaksipulsa` join `tblcustomer` on(`tbltransaksipulsa`.`idCustomer` = `tblcustomer`.`idCustomer`)) join `tblmitra` on(`tbltransaksipulsa`.`idMitra` = `tblmitra`.`idMitra`)) where `tbltransaksipulsa`.`statusAktif` = '1' and `tbltransaksipulsa`.`statusTransaksi` = 'selesai') */;

/*View structure for view vwdonetransaksisaldo */

/*!50001 DROP TABLE IF EXISTS `vwdonetransaksisaldo` */;
/*!50001 DROP VIEW IF EXISTS `vwdonetransaksisaldo` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwdonetransaksisaldo` AS (select `tbltransaksisaldo`.`idTransaksiSaldo` AS `idTransaksiSaldo`,`tbltransaksisaldo`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tbltransaksisaldo`.`jumlahSaldo` AS `jumlahSaldo`,`tbltransaksisaldo`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksisaldo`.`statusTransaksi` AS `statusTransaksi` from (`tbltransaksisaldo` join `tblmitra` on(`tbltransaksisaldo`.`idMitra` = `tblmitra`.`idMitra`)) where `tbltransaksisaldo`.`statusAktif` = '1' and `tbltransaksisaldo`.`statusTransaksi` = 'selesai') */;

/*View structure for view vwmitranonverifikasi */

/*!50001 DROP TABLE IF EXISTS `vwmitranonverifikasi` */;
/*!50001 DROP VIEW IF EXISTS `vwmitranonverifikasi` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwmitranonverifikasi` AS (select `tblmitra`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tblmitra`.`emailMitra` AS `emailMitra`,`tblmitra`.`passwordMitra` AS `passwordMitra`,`tblmitra`.`statusVerifikasi` AS `statusVerifikasi` from `tblmitra` where `tblmitra`.`statusAktif` = '1' and `tblmitra`.`statusVerifikasi` = '0') */;

/*View structure for view vwmitraterverifikasi */

/*!50001 DROP TABLE IF EXISTS `vwmitraterverifikasi` */;
/*!50001 DROP VIEW IF EXISTS `vwmitraterverifikasi` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwmitraterverifikasi` AS (select `tblmitra`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tblmitra`.`emailMitra` AS `emailMitra`,`tblmitra`.`passwordMitra` AS `passwordMitra`,`tblmitra`.`statusVerifikasi` AS `statusVerifikasi` from `tblmitra` where `tblmitra`.`statusAktif` = '1' and `tblmitra`.`statusVerifikasi` = '1') */;

/*View structure for view vwpaketaktif */

/*!50001 DROP TABLE IF EXISTS `vwpaketaktif` */;
/*!50001 DROP VIEW IF EXISTS `vwpaketaktif` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpaketaktif` AS (select `tblpaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`deskripsiPaket` AS `deskripsiPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tblpaket`.`statusAktif` AS `statusAktif` from `tblpaket` where `tblpaket`.`statusAktif` = '1') */;

/*View structure for view vwpaketnonaktif */

/*!50001 DROP TABLE IF EXISTS `vwpaketnonaktif` */;
/*!50001 DROP VIEW IF EXISTS `vwpaketnonaktif` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpaketnonaktif` AS (select `tblpaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`deskripsiPaket` AS `deskripsiPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tblpaket`.`statusAktif` AS `statusAktif` from `tblpaket` where `tblpaket`.`statusAktif` = '0') */;

/*View structure for view vwpendingtransaksipaket */

/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksipaket` */;
/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksipaket` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpendingtransaksipaket` AS (select `tbltransaksipaket`.`idTransaksiPaket` AS `idTransaksiPaket`,`tbltransaksipaket`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipaket`.`idPaket` AS `idPaket`,`tblpaket`.`namaPaket` AS `namaPaket`,`tblpaket`.`kuota` AS `kuota`,`tblpaket`.`hargaPaket` AS `hargaPaket`,`tbltransaksipaket`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipaket`.`statusTransaksi` AS `statusTransaksi` from ((`tbltransaksipaket` join `tblcustomer` on(`tbltransaksipaket`.`idCustomer` = `tblcustomer`.`idCustomer`)) join `tblpaket` on(`tbltransaksipaket`.`idPaket` = `tblpaket`.`idPaket`)) where `tbltransaksipaket`.`statusAktif` = '1' and `tbltransaksipaket`.`statusTransaksi` = 'diproses' and `tblcustomer`.`statusAktif` = '1') */;

/*View structure for view vwpendingtransaksipulsa */

/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksipulsa` */;
/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksipulsa` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpendingtransaksipulsa` AS (select `tbltransaksipulsa`.`idTransaksiPulsa` AS `idTransaksiPulsa`,`tbltransaksipulsa`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tbltransaksipulsa`.`jumlahPulsa` AS `jumlahPulsa`,`tbltransaksipulsa`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksipulsa`.`statusTransaksi` AS `statusTransaksi` from (`tbltransaksipulsa` join `tblcustomer` on(`tbltransaksipulsa`.`idCustomer` = `tblcustomer`.`idCustomer`)) where `tbltransaksipulsa`.`statusAktif` = '1' and `tbltransaksipulsa`.`statusTransaksi` = 'diproses' and `tblcustomer`.`statusAktif` = '1') */;

/*View structure for view vwpendingtransaksisaldo */

/*!50001 DROP TABLE IF EXISTS `vwpendingtransaksisaldo` */;
/*!50001 DROP VIEW IF EXISTS `vwpendingtransaksisaldo` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpendingtransaksisaldo` AS (select `tbltransaksisaldo`.`idTransaksiSaldo` AS `idTransaksiSaldo`,`tbltransaksisaldo`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tbltransaksisaldo`.`jumlahSaldo` AS `jumlahSaldo`,`tbltransaksisaldo`.`waktuTransaksi` AS `waktuTransaksi`,`tbltransaksisaldo`.`statusTransaksi` AS `statusTransaksi` from (`tbltransaksisaldo` join `tblmitra` on(`tbltransaksisaldo`.`idMitra` = `tblmitra`.`idMitra`)) where `tbltransaksisaldo`.`statusAktif` = '1' and `tbltransaksisaldo`.`statusTransaksi` = 'diproses' and `tblmitra`.`statusAktif` = '1') */;

/*View structure for view vwpulsakuotacustomer */

/*!50001 DROP TABLE IF EXISTS `vwpulsakuotacustomer` */;
/*!50001 DROP VIEW IF EXISTS `vwpulsakuotacustomer` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwpulsakuotacustomer` AS (select `tblpulsakuotacustomer`.`idPulsaKuotaCustomer` AS `idPulsaKuotaCustomer`,`tblpulsakuotacustomer`.`idCustomer` AS `idCustomer`,`tblcustomer`.`namaCustomer` AS `namaCustomer`,`tblcustomer`.`nomorHpCustomer` AS `nomorHpCustomer`,`tblpulsakuotacustomer`.`pulsaCustomer` AS `pulsaCustomer`,`tblpulsakuotacustomer`.`kuotaCustomer` AS `kuotaCustomer` from (`tblpulsakuotacustomer` join `tblcustomer` on(`tblpulsakuotacustomer`.`idCustomer` = `tblcustomer`.`idCustomer`)) where `tblcustomer`.`statusAktif` = '1') */;

/*View structure for view vwsaldomitra */

/*!50001 DROP TABLE IF EXISTS `vwsaldomitra` */;
/*!50001 DROP VIEW IF EXISTS `vwsaldomitra` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwsaldomitra` AS (select `tblsaldomitra`.`idSaldoMitra` AS `idSaldoMitra`,`tblsaldomitra`.`idMitra` AS `idMitra`,`tblmitra`.`namaMitra` AS `namaMitra`,`tblmitra`.`emailMitra` AS `emailMitra`,`tblsaldomitra`.`saldoMitra` AS `saldoMitra` from (`tblsaldomitra` join `tblmitra` on(`tblsaldomitra`.`idMitra` = `tblmitra`.`idMitra`)) where `tblmitra`.`statusAktif` = '1' and `tblmitra`.`statusVerifikasi` = '1') */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
